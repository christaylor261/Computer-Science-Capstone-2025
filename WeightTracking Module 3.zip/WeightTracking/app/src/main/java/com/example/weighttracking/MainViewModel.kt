package com.example.weighttracking

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weighttracking.data.UserWeight
import com.example.weighttracking.data.WeightRepository
import kotlinx.coroutines.launch

/**
 * MainViewModel holds the app's business logic and interacts with the repository.
 * @param repository The WeightRepository that provides data operations for weight entries.
 */
class MainViewModel(private val repository: WeightRepository) : ViewModel() {

    // LiveData holding a list of UserWeight objects from the repository
    val userWeights: LiveData<List<UserWeight>> = repository.allWeights

    /**
     * Function to add a new weight entry to the database via the repository.
     * @param userWeight The UserWeight object containing date and weight information.
     */
    fun addWeight(userWeight: UserWeight) {
        viewModelScope.launch {
            repository.insertWeight(userWeight)
        }
    }
}
