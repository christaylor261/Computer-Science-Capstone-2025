package com.example.weighttracking.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_weights")
data class UserWeight(
    @PrimaryKey val date: String,
    val weight: Float
)
