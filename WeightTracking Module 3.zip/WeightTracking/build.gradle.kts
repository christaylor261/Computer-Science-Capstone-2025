// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    // The Kotlin Compose plugin is not needed for Jetpack Compose on Android,
    // so we comment it out if it’s defined in the version catalog:
    // alias(libs.plugins.kotlin.compose) apply false
}

// You can keep or remove this block if you have other shared build settings or subproject configurations:
subprojects {
    // Common configuration for all subprojects, if needed.
}

// If you have pluginManagement or dependencyResolutionManagement, that usually goes in settings.gradle.kts
