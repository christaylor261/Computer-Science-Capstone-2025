plugins {
    // Android application plugin (AGP)
    alias(libs.plugins.android.application)
    // Kotlin Android plugin
    alias(libs.plugins.kotlin.android)
    // **Required for Compose in Kotlin 2.0+**
    alias(libs.plugins.kotlin.compose)
    id("com.google.devtools.ksp") version "2.1.10-1.0.31"
}

android {
    namespace = "com.example.weighttracking"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.weighttracking"
        minSdk = 34
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.4.3"
    }
    ksp {
        arg("room.schemaLocation", "$projectDir/schemas")
        arg("room.incremental", "true")
    }
}

// Force Kotlin to use Java 17 toolchain
kotlin {
    jvmToolchain {
        languageVersion = JavaLanguageVersion.of(17)
    }
}
dependencies {
    // Core Android + Kotlin
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)

    // Jetpack Compose BOM + UI libraries
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)

    // DataStore Preferences dependency
    implementation(libs.androidx.datastore.preferences)

    // AppCompat for backward compatibility
    implementation(libs.androidx.appcompat)

    // Room dependencies (using unified version 2.6.1)
    implementation(libs.androidx.room.common)
    implementation(libs.androidx.room.common.jvm)
    implementation("androidx.room:room-runtime:2.6.1")
    // Use KSP for Room annotation processing instead of kapt
    ksp("androidx.room:room-compiler:2.6.1")
    implementation(libs.androidx.room.ktx)

    // Lifecycle ViewModel Compose dependency
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.6.1")

    // Testing dependencies
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)
}
