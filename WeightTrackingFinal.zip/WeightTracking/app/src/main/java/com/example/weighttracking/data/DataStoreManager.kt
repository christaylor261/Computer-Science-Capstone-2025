package com.example.weighttracking.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

// Extension property to create a DataStore instance named "weight_preferences"
val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "weight_preferences")

class DataStoreManager(private val context: Context) {

    companion object {
        // Keys for data to store in DataStore
        val WEIGHT_UNIT_KEY = stringPreferencesKey("weight_unit")
        val GOAL_WEIGHT_KEY = intPreferencesKey("goal_weight")
    }

    // Observing the preferred weight unit as a Flow (updates whenever changed)
    val weightUnitFlow: Flow<String?> = context.dataStore.data
        .map { preferences ->
            // Return the saved weight unit or "kg" as a default
            preferences[WEIGHT_UNIT_KEY] ?: "kg"
        }

    // Observing the goal weight as a Flow
    val goalWeightFlow: Flow<Int> = context.dataStore.data
        .map { preferences ->
            // Return the saved goal weight or a default value of 70
            preferences[GOAL_WEIGHT_KEY] ?: 70
        }

    // Suspend function to save the preferred weight unit
    suspend fun saveWeightUnit(weightUnit: String) {
        context.dataStore.edit { preferences ->
            preferences[WEIGHT_UNIT_KEY] = weightUnit
        }
    }

    // Suspend function to save the goal weight
    suspend fun saveGoalWeight(goalWeight: Int) {
        context.dataStore.edit { preferences ->
            preferences[GOAL_WEIGHT_KEY] = goalWeight
        }
    }

    // Optional: Retrieve the weight unit once, without observing a Flow
    // This is useful if we need a one-time read (e.g., on startup)
    suspend fun getWeightUnitOnce(): String {
        val prefs = context.dataStore.data.first()
        return prefs[WEIGHT_UNIT_KEY] ?: "kg"
    }

    // Optional: Retrieve the goal weight once, without observing a Flow
    suspend fun getGoalWeightOnce(): Int {
        val prefs = context.dataStore.data.first()
        return prefs[GOAL_WEIGHT_KEY] ?: 70
    }
}
