package com.example.weighttracking.ui.theme

import androidx.compose.ui.graphics.Color

// Blue and Gray color palette
val BluePrimary = Color(0xFF1976D2)       // A strong blue
val BlueVariant = Color(0xFF1565C0)       // Slightly darker blue
val GrayBackground = Color(0xFFF5F5F5)    // Light gray background
val GraySurface = Color(0xFFEEEEEE)       // Mid-tone gray for surfaces/cards
val GrayText = Color(0xFF424242)          // Dark gray for text
