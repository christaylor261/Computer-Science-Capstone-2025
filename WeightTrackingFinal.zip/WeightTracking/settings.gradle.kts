pluginManagement {
    repositories {
        // Google repository for AGP and Android-related plugins
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        // Maven Central for libraries/plugins not found in Google
        mavenCentral()
        // Gradle Plugin Portal for general Gradle plugins (including KSP)
        gradlePluginPortal()
        // JetBrains Compose repository (needed if using Compose Desktop or Multiplatform)
        maven("https://maven.pkg.jetbrains.space/public/p/compose/dev")
        maven("https://maven.pkg.jetbrains.space/kotlin/p/kotlin/early-access")
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        // Google for Android libraries
        google()
        // Maven Central for most other libraries
        mavenCentral()
        // JetBrains Compose repository (only if needed Compose Desktop/MPP)
        maven("https://maven.pkg.jetbrains.space/public/p/compose/dev")
        // Kotlin EAP repository for early access Kotlin versions
        maven("https://maven.pkg.jetbrains.space/kotlin/p/kotlin/early-access")
    }
}

rootProject.name = "WeightTracking"
include(":app")
