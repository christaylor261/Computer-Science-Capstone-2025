package com.example.weighttracking.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface WeightDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeight(userWeight: UserWeight)

    @Query("SELECT * FROM user_weights ORDER BY date DESC")
    fun getAllWeights(): LiveData<List<UserWeight>>
}
