package com.example.weighttracking

import android.Manifest
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.weighttracking.data.DataStoreManager
import com.example.weighttracking.data.UserWeight
import com.example.weighttracking.ui.theme.WeightTrackingTheme
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

// Enum to represent app screens
enum class Screen {
    Login, MainDashboard, WeightEntry, GoalWeight, CreateAccount
}

// Simulated user database for login operations
object UserDatabase {
    val users = mutableMapOf<String, String>()
    fun addUser(username: String, password: String) {
        users[username] = password
    }
    fun validateUser(username: String, password: String): Boolean {
        return users[username]?.equals(password) ?: false
    }
}

// MainActivity now extends ComponentActivity and initializes DataStoreManager
class MainActivity : ComponentActivity() {
    private lateinit var dataStoreManager: DataStoreManager

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dataStoreManager = DataStoreManager(applicationContext)
        setContent {
            WeightTrackingTheme {
                // Inject DataStoreManager into Navigation
                Navigation(dataStoreManager)
            }
        }
    }
}

// Navigation composable manages screen switching based on current state
@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun Navigation(dataStoreManager: DataStoreManager) {
    var currentScreen by remember { mutableStateOf(Screen.Login) }
    var showCreateAccountMessage by remember { mutableStateOf(false) }
    val weightData = remember { mutableStateListOf<Pair<String, String>>() }
    var goalWeight by remember { mutableStateOf<String?>(null) }

    when (currentScreen) {
        Screen.Login -> LoginScreen(
            dataStoreManager = dataStoreManager,
            onLogin = { currentScreen = Screen.MainDashboard },
            onCreateAccount = { currentScreen = Screen.CreateAccount },
            showCreateAccountMessage = showCreateAccountMessage
        )
        Screen.MainDashboard -> MainDashboardScreen(
            onAddWeight = { currentScreen = Screen.WeightEntry },
            onViewGoals = { currentScreen = Screen.GoalWeight }
        )
        Screen.WeightEntry -> WeightEntryScreen(
            dataStoreManager = dataStoreManager,
            onBack = { currentScreen = Screen.MainDashboard },
            weightData = weightData
        )
        Screen.GoalWeight -> GoalWeightScreen(
            dataStoreManager = dataStoreManager,
            onBack = { currentScreen = Screen.MainDashboard },
            weightData = weightData,
            goalWeight = goalWeight,
            onSetGoalWeight = { goalWeight = it }
        )
        Screen.CreateAccount -> CreateAccountScreen(
            dataStoreManager = dataStoreManager,
            onAccountCreated = {
                showCreateAccountMessage = true
                currentScreen = Screen.Login
            }
        )
    }
}

// Composable for the Login screen with DataStore integration
@Composable
fun LoginScreen(
    dataStoreManager: DataStoreManager,
    onLogin: () -> Unit,
    onCreateAccount: () -> Unit,
    showCreateAccountMessage: Boolean
) {
    val context = LocalContext.current
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Weight Tracker", style = MaterialTheme.typography.headlineMedium)

        if (showCreateAccountMessage) {
            Text(
                "Account created. Please log in to continue.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.primary
            )
        }

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        if (errorMessage.isNotEmpty()) {
            Text(
                errorMessage,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                if (username.isEmpty() || password.isEmpty()) {
                    errorMessage = "Please enter both username and password."
                } else if (UserDatabase.validateUser(username, password)) {
                    onLogin()
                } else {
                    errorMessage = "Incorrect username or password."
                }
            },
            modifier = Modifier.padding(8.dp)
        ) {
            Text("Login")
        }

        Button(onClick = onCreateAccount, modifier = Modifier.padding(8.dp)) {
            Text("Create Account")
        }
    }
}

// Composable for the Main Dashboard screen with navigation options
@Composable
fun MainDashboardScreen(onAddWeight: () -> Unit, onViewGoals: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Main Dashboard", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = onAddWeight, modifier = Modifier.padding(8.dp)) {
            Text("Add Weight")
        }
        Button(onClick = onViewGoals, modifier = Modifier.padding(8.dp)) {
            Text("View Goals")
        }
    }
}

// Composable for the Weight Entry screen with minimal algorithm enhancements
@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun WeightEntryScreen(
    dataStoreManager: DataStoreManager,
    onBack: () -> Unit,
    weightData: SnapshotStateList<Pair<String, String>>
) {
    // Obtain the MainViewModel instance using the viewModel() helper and factory.
    val viewModel: MainViewModel = viewModel(factory = MainViewModelFactory(LocalContext.current))
    var newWeight by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var smsEnabled by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            sendSMSNotification("Weight entry added: $newWeight", context)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            "Weight Entry Screen",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onBack, modifier = Modifier.align(Alignment.Start)) {
            Text("Back to Dashboard")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { showAddDialog = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Add Weight Entry")
        }
        Spacer(modifier = Modifier.height(16.dp))
        // Display weight entries sorted in descending order by timestamp
        LazyColumn(modifier = Modifier.fillMaxHeight()) {
            items(weightData.sortedByDescending { it.second }) { item ->
                WeightEntryRow(
                    weight = item.first,
                    date = item.second,
                    onDelete = { weightData.remove(item) }
                )
            }
        }
        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("Add New Weight Entry") },
                text = {
                    Column {
                        OutlinedTextField(
                            value = newWeight,
                            onValueChange = { newWeight = it },
                            label = { Text("Weight") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = smsEnabled,
                                onCheckedChange = { smsEnabled = it }
                            )
                            Text("Enable SMS Notifications")
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        // Validate input: Ensure newWeight is a valid, positive number.
                        val weightValue = newWeight.toFloatOrNull()
                        if (weightValue == null || weightValue <= 0f) {
                            // Optionally, you can show an error message or simply ignore invalid input.
                            return@Button
                        }
                        val timestamp = LocalDateTime.now()
                            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                        // Create a new weight entry using Room via ViewModel
                        viewModel.addWeight(UserWeight(date = timestamp, weight = weightValue))
                        // Optionally, update the local state for immediate UI feedback
                        weightData.add(newWeight to timestamp)
                        if (smsEnabled) {
                            launcher.launch(Manifest.permission.SEND_SMS)
                        }
                        newWeight = ""
                        showAddDialog = false
                    }) {
                        Text("Add")
                    }
                },
                dismissButton = {
                    Button(onClick = { showAddDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

// Composable for each weight entry row displayed in the list
@Composable
fun WeightEntryRow(weight: String, date: String, onDelete: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("Weight: $weight", style = MaterialTheme.typography.bodyLarge)
            Text("Date: $date", style = MaterialTheme.typography.bodySmall)
        }
        Button(onClick = onDelete) {
            Text("Delete")
        }
    }
}

// Helper function to safely perform division, avoiding division by zero.
fun safeDivide(numerator: Float, denominator: Float): Float {
    return if (denominator == 0f) 0f else numerator / denominator
}

@Suppress("DEPRECATION")
fun sendSMSNotification(message: String, context: Context) {
    try {
        // Retrieve the default SMS subscription ID.
        val subscriptionId = SmsManager.getDefaultSmsSubscriptionId()
        // Get the SmsManager instance for the default subscription.
        val smsManager = SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
        // Replace with the actual recipient's phone number.
        val phoneNumber = "1234567890"
        smsManager.sendTextMessage(phoneNumber, null, message, null, null)
        println("SMS Sent: $message")
    } catch (e: Exception) {
        println("Failed to send SMS: ${e.message}")
    }
}

// Composable for the Goal Weight screen where users can set their goal weight
@Composable
fun GoalWeightScreen(
    dataStoreManager: DataStoreManager,
    onBack: () -> Unit,
    weightData: List<Pair<String, String>>,
    goalWeight: String?,
    onSetGoalWeight: (String) -> Unit
) {
    var newGoalWeight by remember { mutableStateOf(goalWeight ?: "") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Goal Weight Screen", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = newGoalWeight,
            onValueChange = { newGoalWeight = it },
            label = { Text("Set Goal Weight") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(onClick = { onSetGoalWeight(newGoalWeight) }) {
            Text("Save Goal Weight")
        }

        Spacer(Modifier.height(16.dp))

        Button(onClick = onBack, modifier = Modifier.padding(8.dp)) {
            Text("Back to Dashboard")
        }

        if (weightData.isNotEmpty() && goalWeight != null) {
            val latestWeight = weightData.last().first
            Text("Latest Weight: $latestWeight kg", style = MaterialTheme.typography.bodyLarge)
            Text("Goal Weight: $goalWeight kg", style = MaterialTheme.typography.bodyLarge)
            // Use safeDivide to calculate progress safely
            val progress = safeDivide(latestWeight.toFloat(), goalWeight.toFloat()) * 100
            Text("Progress: ${progress.toInt()}% toward goal")
        }
    }
}

// Composable for the Create Account screen where users can register an account
@Composable
fun CreateAccountScreen(
    dataStoreManager: DataStoreManager,
    onAccountCreated: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Create Account", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        if (errorMessage.isNotEmpty()) {
            Text(errorMessage, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            if (username.isEmpty() || password.isEmpty()) {
                errorMessage = "Both fields are required."
            } else {
                // Save the new user using DataStoreManager if desired.
                // Here, we also update the in-memory UserDatabase.
                UserDatabase.addUser(username, password)
                onAccountCreated()
            }
        }) {
            Text("Create Account")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    WeightTrackingTheme {
        Navigation(DataStoreManager(LocalContext.current))
    }
}
