package com.example.weighttracking

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.weighttracking.data.WeightDatabase
import com.example.weighttracking.data.WeightRepository

/**
 * ViewModelFactory to create an instance of MainViewModel with the required repository.
 * @param context The context used to retrieve an instance of the WeightDatabase.
 */
class MainViewModelFactory(private val context: Context) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            // Get an instance of the WeightDatabase and create a WeightRepository from it
            val database = WeightDatabase.getDatabase(context)
            val repository = WeightRepository(database.weightDao())
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
