package com.example.weighttracking.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "user_weights",
    indices = [Index(value = ["date"])]
)
data class UserWeight(
    @PrimaryKey val date: String,
    val weight: Float
)
