package com.example.weighttracking.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface WeightDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeight(userWeight: UserWeight)

    @Query("SELECT * FROM user_weights ORDER BY date DESC")
    fun getAllWeights(): LiveData<List<UserWeight>>

    // New method: Retrieves weight entries between the specified start and end dates,
    // ordered by date in descending order.
    @Query("SELECT * FROM user_weights WHERE date BETWEEN :startDate AND :endDate ORDER BY date DESC")
    fun getWeightsBetween(startDate: String, endDate: String): LiveData<List<UserWeight>>
}
