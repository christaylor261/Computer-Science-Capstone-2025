package com.example.weighttracking.data

import androidx.lifecycle.LiveData

class WeightRepository(private val weightDao: WeightDao) {

    // LiveData of all user weight entries
    val allWeights: LiveData<List<UserWeight>> = weightDao.getAllWeights()

    // Insert a new weight entry
    suspend fun insertWeight(userWeight: UserWeight) {
        weightDao.insertWeight(userWeight)
    }
}
